Markbase uses "garden plots" to refer to the sections of your digital garden. These are the folders or directories of how you organize the notes in your garden.

A example, the [[Markbase Garden Center]] is organized into plots like:
- Welcome Center
- Garden Guides
- Garden Plans